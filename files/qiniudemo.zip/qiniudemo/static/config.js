//其实这个文件是不需要的

//module.exports = {
//    'ACCESS_KEY': '',
//    'SECRET_KEY': '',
//    'Bucket_Name': '',
//    'Port': 19110,
//    'Uptoken_Url': '/video/uptoken',
//    'Domain': 'http://whyeduvideo.qiniudn.com/'
//};

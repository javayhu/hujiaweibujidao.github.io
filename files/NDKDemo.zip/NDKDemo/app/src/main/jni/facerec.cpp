#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/contrib/contrib.hpp>
#include <opencv2/contrib/detection_based_tracker.hpp>

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT jlong JNICALL Java_com_android_hacks_ndkdemo_FisherFaceRecognizer_createFisherFaceRecognizer0(JNIEnv*, jclass);
JNIEXPORT jlong JNICALL Java_com_android_hacks_ndkdemo_FisherFaceRecognizer_createFisherFaceRecognizer0(JNIEnv* env, jclass obj) {
    try {
        cv::Ptr<cv::FaceRecognizer> pfr = cv::createFisherFaceRecognizer();
        pfr.addref(); // this is for the 2.4 branch, 3.0 would need a different treatment here
        return (jlong) pfr.obj;
    } catch (...) {
        jclass je = env->FindClass("java/lang/Exception");
        env->ThrowNew(je, "sorry, dave..");
    }
    return 0;
}

JNIEXPORT jlong JNICALL Java_com_android_hacks_ndkdemo_FisherFaceRecognizer_createFisherFaceRecognizer1(JNIEnv*, jclass, jint);
JNIEXPORT jlong JNICALL Java_com_android_hacks_ndkdemo_FisherFaceRecognizer_createFisherFaceRecognizer1(JNIEnv* env, jclass obj, jint num_components) {
    try {
        cv::Ptr<cv::FaceRecognizer> pfr = cv::createFisherFaceRecognizer(num_components);
        pfr.addref();
        return (jlong) pfr.obj;
    } catch (...) {
        jclass je = env->FindClass("java/lang/Exception");
        env->ThrowNew(je, "sorry, dave..");
    }
    return 0;
}

JNIEXPORT jlong JNICALL Java_com_android_hacks_ndkdemo_FisherFaceRecognizer_createFisherFaceRecognizer2(JNIEnv*, jclass, jint, jdouble);
JNIEXPORT jlong JNICALL Java_com_android_hacks_ndkdemo_FisherFaceRecognizer_createFisherFaceRecognizer2(JNIEnv* env, jclass obj, jint num_components, jdouble threshold) {
    try {
        cv::Ptr<cv::FaceRecognizer> pfr = cv::createFisherFaceRecognizer(num_components,threshold);
        pfr.addref();
        return (jlong) pfr.obj;
    } catch (...) {
        jclass je = env->FindClass("java/lang/Exception");
        env->ThrowNew(je, "sorry, dave..");
    }
    return 0;
}

#ifdef __cplusplus
}
#endif
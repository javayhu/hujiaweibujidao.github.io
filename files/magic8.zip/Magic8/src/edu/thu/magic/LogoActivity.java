package edu.thu.magic;

import edu.thu.magic.util.CommonUtil;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

/**
 * ������
 * 
 * @author hujiawei
 * 
 */
public class LogoActivity extends Activity {

	private SharedPreferences preferences;// Ӧ������
	private String SOUND = "sound";// �Ƿ�����Ч��keyֵ
	private MenuItem soundItem;// ��Ч�˵���
	private ImageView iv_logo_rat;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_logo);

		iv_logo_rat = (ImageView) findViewById(R.id.iv_logo_rat);
		AnimationDrawable animationDrawable = (AnimationDrawable) iv_logo_rat.getBackground();
		animationDrawable.start();

		// �õ�Ӧ�����ݣ�������һ����ֵ��
		preferences = getSharedPreferences(CommonUtil.MAGIC_8, MODE_PRIVATE);
		if (!preferences.contains(SOUND)) {
			Editor editor = preferences.edit();
			editor.putBoolean(SOUND, true);
			editor.commit();
		}
	}

	@Override
	// �����ڸ��²˵�
	public boolean onPrepareOptionsMenu(Menu menu) {
		super.onPrepareOptionsMenu(menu);
		System.out.println("onPrepareOptionsMenu");
		System.out.println("sound:" + preferences.getBoolean(SOUND, true));
		if (preferences.getBoolean(SOUND, true)) {
			soundItem.setTitle("�ر���Ч");
		} else {
			soundItem.setTitle("������Ч");
		}
		return true;
	}

	@Override
	// �����˵�
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, 0, 0, "��������");
		if (preferences.getBoolean(SOUND, true)) {
			soundItem = menu.add(0, 1, 0, "�ر���Ч");
		} else {
			soundItem = menu.add(0, 1, 0, "������Ч");
		}
		return true;
	}

	@Override
	// �����˵��ѡ��
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == 0) {
			Intent intent = new Intent(LogoActivity.this, AboutActivity.class);
			startActivity(intent);
		} else {
			boolean sound = preferences.getBoolean(SOUND, true);
			Editor editor = preferences.edit();
			editor.putBoolean(SOUND, !sound);
			editor.commit();
		}
		return true;
	}

	// ����ħ�������
	public void btn_logo_magic(View view) {
		Intent intent = new Intent(LogoActivity.this, MagicActivity.class);
		startActivity(intent);
	}

}

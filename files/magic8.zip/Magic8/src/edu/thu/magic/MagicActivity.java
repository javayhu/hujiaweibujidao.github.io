package edu.thu.magic;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;

import android.app.Activity;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.RelativeLayout;
import android.widget.TextView;
import edu.thu.magic.listener.ShakeListener;
import edu.thu.magic.listener.ShakeListener.OnShakeListener;
import edu.thu.magic.util.CommonUtil;

/**
 * magic 8
 * 
 * @author hujiawei
 * 
 */
public class MagicActivity extends Activity {

	private ShakeListener shakeListener;// �ֻ��ζ�������

	private RelativeLayout rl_shake_handup;// ��������ͼƬ���ϲ���

	private RelativeLayout rl_shake_handdown;// ��������ͼƬ���²���

	private RelativeLayout rl_shake_result;// ҡ�����Ľ����

	private TextView tv_shake_content;// ���������

	private Vibrator vibrator;// ����

	private int[] sounds = { R.raw.shake_sound, R.raw.shake_match, R.raw.shake_nomatch };// ������Դ

	private MediaPlayer[] soundPlayers;// ��Ч������

	private Handler handler;// ��Ϣ������

	// http://en.wikipedia.org/wiki/Magic_8-Ball
	private String[] magicResults;// ħ����Ľ������20��

	private SharedPreferences preferences;// Ӧ������

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_magic);
		
//		Button button = new Button(this);
//		button.setText("��������");
//		button.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));

		preferences = getSharedPreferences(CommonUtil.MAGIC_8, MODE_PRIVATE);
		//
		magicResults = new String[] { "It is certain", "Don't count on it", "Ask again later", "Yes definitely",
				"It is decidedly so", "Reply hazy try again", "Without a doubt", "Better not tell you now",
				"My reply is no", "Outlook good", "Outlook not so good", "Cannot predict now", "Most likely",
				"As I see it yes", "You may rely on it", "Concentrate and ask again", "Signs point to yes",
				"Very doubtful", "Most likely", "Yes" };

		// �õ�ϵͳ���񶯷���
		vibrator = (Vibrator) getApplication().getSystemService(VIBRATOR_SERVICE);
		// ������Ч������
		soundPlayers = new MediaPlayer[sounds.length];
		for (int i = 0; i < soundPlayers.length; i++) {
			soundPlayers[i] = MediaPlayer.create(this, sounds[i]);
			soundPlayers[i].setAudioStreamType(AudioManager.STREAM_MUSIC);
		}

		// �ζ����
		rl_shake_result = (RelativeLayout) findViewById(R.id.rl_shake_result);
		rl_shake_result.setVisibility(View.GONE);

		// ���²��ֺͽ��textview
		rl_shake_handup = (RelativeLayout) findViewById(R.id.rl_shake_handup);
		rl_shake_handdown = (RelativeLayout) findViewById(R.id.rl_shake_handdown);
		tv_shake_content = (TextView) findViewById(R.id.tv_shake_content);

		// ������ע�������
		shakeListener = new ShakeListener(MagicActivity.this);
		shakeListener.setOnShakeListener(new OnShakeListener() {
			public void onShake() {
				startVibrate();
				if (preferences.getBoolean("sound", true)) {
					soundPlayers[0].start();
				}
				if (rl_shake_result.getVisibility() != View.GONE) {
					TranslateAnimation downAnimation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0f,
							Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF,
							+5f);// move it off
					downAnimation.setDuration(500);
					downAnimation.setFillAfter(true);
					rl_shake_result.startAnimation(downAnimation);
					rl_shake_result.setVisibility(View.GONE);// direct gone no use
				}
				startAnimation();
				shakeListener.stop();
				new GetAQIDataThread().start();
			}
		});
		
		// ��Ϣ������
		handler = new Handler() {
			public void handleMessage(Message message) {
				StringBuffer buffer = new StringBuffer();
				if (message.obj != null) {
					String result = (String) message.obj;
					System.out.println("result:" + result);
					// 2013-12-8-14-Very Unhealthy-234-120-43-29-5-9-9--6-34-1019
					buffer.append(getAQIresult(Integer.parseInt(result.split("-")[5])));// �õ�����234��
					if (preferences.getBoolean("sound", true)) {
						soundPlayers[1].start();// match -> �õ�����
					}
				} else {
					if (preferences.getBoolean("sound", true)) {
						soundPlayers[2].start();// not match-> û�еõ�����
					}
				}
				buffer.append(magicResults[new Random().nextInt(20)]);// // [0,n)
				tv_shake_content.setText(buffer.toString());
				startResultAnimation();
				vibrator.cancel();
				shakeListener.start();
			}
		};
		
		new GetAQIDataThread().start();

	}

	// �õ����������Ľ��
	public String getAQIresult(int index) {
		if (index < 51) {
			return "[����������]";
		} else if (index < 101) {
			return "[������������]";
		} else if (index < 151) {
			return "[�����Ⱦ]";
		} else if (index < 201) {
			return "[�ж���Ⱦ]";
		} else if (index < 301) {
			return "[�ض���Ⱦ]";
		} else {
			return "[������Ⱦ]";
		}
	}

	// ������ʾ����Ķ���
	private void startResultAnimation() {
		TranslateAnimation downAnimation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0f,
				Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, -1.2f, Animation.RELATIVE_TO_SELF, 0f);
		downAnimation.setDuration(1000);
		downAnimation.setFillAfter(true);
		rl_shake_result.setVisibility(View.VISIBLE);
		rl_shake_result.startAnimation(downAnimation);
	}

	// ��ȡ���������������߳�
	class GetAQIDataThread extends Thread {
		public void run() {
			try {
				URL url = new URL(CommonUtil.AQIDATA_URL);
				HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
				urlConnection.setRequestMethod("GET");
				BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
				StringBuffer result = new StringBuffer();
				String line = null;
				while ((line = reader.readLine()) != null) {
					result.append(line);
				}
				System.out.println(result);// 2013-12-8-14-Very Unhealthy-234-120-43-29-5-9-9--6-34-1019
				urlConnection.getInputStream().close();
				urlConnection.disconnect();

				// ������Ϣ
				Message message = new Message();
				if ("".equalsIgnoreCase(result.toString())) {
					message.obj = null;
				}else {
					message.obj = result.toString();
				}
				handler.sendMessage(message);
			} catch (Exception e) {
				// e.printStackTrace();
				Message message = new Message();
				message.obj = null;
				handler.sendMessage(message);
			}
		}
	}

	// ��ʼ��ʾ����
	public void startAnimation() {
		AnimationSet animup = new AnimationSet(true);
		TranslateAnimation mytranslateanimup0 = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0f,
				Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, -0.5f);
		mytranslateanimup0.setDuration(1000);
		TranslateAnimation mytranslateanimup1 = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0f,
				Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, +0.5f);
		mytranslateanimup1.setDuration(1000);
		mytranslateanimup1.setStartOffset(1000);
		animup.addAnimation(mytranslateanimup0);
		animup.addAnimation(mytranslateanimup1);
		rl_shake_handup.startAnimation(animup);

		AnimationSet animdn = new AnimationSet(true);
		TranslateAnimation mytranslateanimdn0 = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0f,
				Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, +0.5f);
		mytranslateanimdn0.setDuration(1000);
		TranslateAnimation mytranslateanimdn1 = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0f,
				Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, -0.5f);
		mytranslateanimdn1.setDuration(1000);
		mytranslateanimdn1.setStartOffset(1000);
		animdn.addAnimation(mytranslateanimdn0);
		animdn.addAnimation(mytranslateanimdn1);
		rl_shake_handdown.startAnimation(animdn);
	}

	// ��ʼ��
	public void startVibrate() {
		vibrator.vibrate(new long[] { 500, 1000, 500, 1000 }, -1);// -1��ʾ���ظ���
	}
	
	// 
	protected void onPause() {
		super.onPause();
	}

	//
	protected void onResume() {
		super.onResume();
	}

	// �˳����˳�ʱһ��Ҫȷ���ͷ���Ч��Դ����ȡ��������
	protected void onDestroy() {
		super.onDestroy();
		for (MediaPlayer p : soundPlayers) {
			if (p.isPlaying()) {
				p.stop();
			}
			p.release();
		}
		if (shakeListener != null) {
			shakeListener.stop();
		}
	}

	// ����������
	public void btn_shake_back(View view) {
		MagicActivity.this.finish();
	}
}
